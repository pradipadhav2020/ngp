package com.userservice.controller;

import com.userservice.exception.UserNotFoundException;
import com.userservice.model.UserEntity;
import com.userservice.model.pojo.User;
import com.userservice.service.UserService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://localhost:3000/")
@Slf4j
public class UserController {
  private final UserService userService;

  public UserController(UserService userService) {
    this.userService = userService;
  }

  @PostMapping
  public ResponseEntity<User> addUser(
      @RequestBody UserEntity userEntity, HttpServletRequest request) {
    User user = userService.addUser(userEntity);
    URI location =
        ServletUriComponentsBuilder.fromRequestUri(request)
            .path("/{id}")
            .buildAndExpand(user.getId())
            .toUri();
    return ResponseEntity.created(location).body(user);
  }

  @GetMapping("/{id}")
  @CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod = "ratingHotelFallBack")
  ResponseEntity<User> getUser(@PathVariable("id") long userId) throws UserNotFoundException {
    User user = userService.getUserById(userId);
    return ResponseEntity.ok(user);
  }

  ResponseEntity<User> ratingHotelFallBack(long userId, Exception ex) {
    log.info("Fallback method is get executed ", ex.getMessage());
    User user =
        User.builder()
            .name("Dummy")
            .emailId("dummy@gmail.com")
            .designation("service provider")
            .build();
    return new ResponseEntity(user, HttpStatus.OK);
  }

  @PutMapping("/{id}")
  public ResponseEntity<User> updateUser(
      @PathVariable("id") long id, @RequestBody UserEntity userEntity)
      throws UserNotFoundException {
    userEntity.setId(id);
    User user = userService.updateUser(userEntity);
    return new ResponseEntity<>(user, HttpStatus.OK);
  }

  @GetMapping
  ResponseEntity<List<User>> getAllUsers() {
    List<User> userList = userService.getAllUsers();
    return new ResponseEntity<>(userList, HttpStatus.OK);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<String> deleteUser(@PathVariable("id") long id) {
    userService.deleteUserById(id);
    return new ResponseEntity<>("User Successfully Deleted", HttpStatus.OK);
  }
}
