package com.userservice.model.pojo;

import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Rating {
  private long ratingId;
  private long userId;
  private long hotelId;
  private int rating;
  private String feedback;
  private Hotel hotel;
}
