package com.userservice.model.pojo;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
  private long id;
  private String name;
  private String designation;
  private String emailId;
  private List<Rating> ratings;
}
