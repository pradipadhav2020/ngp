package com.userservice.model;

import com.userservice.model.pojo.Rating;
import com.userservice.model.pojo.User;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "employee")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long id;

  @Column(name = "name")
  private String name;

  @Column(name = "designation")
  private String designation;

  @Column(name = "emailId")
  private String emailId;

  public User toBuildUser(List<Rating> ratings) {
    return User.builder()
        .id(this.id)
        .name(this.name)
        .designation(this.designation)
        .emailId(this.emailId)
        .ratings(ratings)
        .build();
  }

  public List<User> toBuildUserList(List<UserEntity> userEntities) {
    List<User> users = new ArrayList<>();
    for (UserEntity userEntity : userEntities) {
      users.add(
          User.builder()
              .id(userEntity.getId())
              .name(userEntity.getName())
              .designation(userEntity.getDesignation())
              .emailId(userEntity.getEmailId())
              .ratings(null)
              .build());
    }
    return users;
  }
}
