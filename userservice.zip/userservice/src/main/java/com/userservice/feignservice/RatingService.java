package com.userservice.feignservice;

import com.userservice.model.pojo.Rating;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient("RATING-SERVICE")
public interface RatingService {
    @GetMapping("/ratings/users/{userId}")
    List<Rating> getAllByUserId(@PathVariable("userId") long userId);
}
