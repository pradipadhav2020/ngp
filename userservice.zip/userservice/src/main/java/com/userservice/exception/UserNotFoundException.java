package com.userservice.exception;

public class UserNotFoundException extends Exception {

  public UserNotFoundException() {
    super("User Not Found Exception");
  }

  public UserNotFoundException(String str) {
    super(str);
  }
}
