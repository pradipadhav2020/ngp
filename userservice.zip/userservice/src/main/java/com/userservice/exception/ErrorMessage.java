package com.userservice.exception;

public class ErrorMessage {
    String uri;
    String msg;

  public ErrorMessage(String uri, String msg) {
    this.uri = uri;
    this.msg = msg;
  }

  public String getUri() {
    return uri;
  }

  public void setUri(String uri) {
    this.uri = uri;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }
}
