package com.userservice.service;

import com.userservice.exception.UserNotFoundException;
import com.userservice.feignservice.HotelService;
import com.userservice.feignservice.RatingService;
import com.userservice.model.UserEntity;
import com.userservice.model.pojo.Hotel;
import com.userservice.model.pojo.Rating;
import com.userservice.model.pojo.User;
import com.userservice.repository.UserRepository;
import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

  private final UserRepository userRepository;
  @Autowired RestTemplate restTemplate;
  @Autowired private HotelService hotelService;
  @Autowired private RatingService ratingService;

  public UserServiceImpl(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public User addUser(UserEntity userEntity) {
    log.info("In addUser :", userEntity);
    UserEntity userEntityResult = userRepository.save(userEntity);
    User user = userEntityResult.toBuildUser(null);
    log.info("User added successfully : ", user);
    return user;
  }

  @Override
  public User getUserById(long id) throws UserNotFoundException {
    UserEntity userResult = userRepository.findById(id).orElseThrow(UserNotFoundException::new);
    List<Rating> ratingList = null;
    if (userResult != null) {
      // When utilizing the restTemplate to interact with the rating service.
      // ratingList = getRatingServiceByUserId(userResult.getId());
      // When utilizing the feign client to interact with the rating service.
      ratingList = ratingService.getAllByUserId(userResult.getId());
    }

    List<Rating> ratings =
        ratingList != null
            ? ratingList.stream()
                .map(
                    rating -> {
                      // When utilizing the restTemplate to interact with the hotel service.
                      // rating.setHotel(getHotelServiceByHotelId(rating.getHotelId()));
                      // When utilizing the feign client to interact with the hotel service.
                      rating.setHotel(hotelService.getHotel(rating.getHotelId()));
                      return rating;
                    })
                .toList()
            : null;
    return userResult.toBuildUser(ratings);
  }

  @Override
  public User updateUser(UserEntity userEntity) throws UserNotFoundException {
    UserEntity existingUserEntity =
        userRepository.findById(userEntity.getId()).orElseThrow(UserNotFoundException::new);
    existingUserEntity.setName(userEntity.getName());
    existingUserEntity.setDesignation(userEntity.getDesignation());
    existingUserEntity.setEmailId(userEntity.getEmailId());
    userRepository.save(existingUserEntity);
    List<Rating> ratingList = null;
    ratingList = getRatingServiceByUserId(existingUserEntity.getId());
    return existingUserEntity.toBuildUser(ratingList);
  }

  @Override
  public List<User> getAllUsers() {
    List<UserEntity> userEntities = userRepository.findAll();
    UserEntity userEntity = new UserEntity();
    return userEntity.toBuildUserList(userEntities);
  }

  @Override
  public void deleteUserById(long id) {
    userRepository.deleteById(id);
    log.info("User Deleted");
  }

  private List<Rating> getRatingServiceByUserId(long userId) {
    Rating[] ratingsArr =
        restTemplate.getForObject("http://RATING-SERVICE/ratings/users/" + userId, Rating[].class);
    List<Rating> ratingList = Arrays.asList(ratingsArr);
    log.info("Rating service result : ", ratingList);
    return ratingList;
  }

  private Hotel getHotelServiceByHotelId(long hotelId) {
    return restTemplate.getForObject("http://HOTEL-SERVICE/hotels/" + hotelId, Hotel.class);
  }
}
