package com.userservice.service;

import com.userservice.exception.UserNotFoundException;
import com.userservice.model.UserEntity;
import com.userservice.model.pojo.User;

import java.util.List;

public interface UserService {
  User addUser(UserEntity user);
  User getUserById(long id) throws UserNotFoundException;
  User updateUser(UserEntity user) throws UserNotFoundException;
  List<User> getAllUsers();
  void deleteUserById(long id);
}
