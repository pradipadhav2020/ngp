package org.example.ngp.reference.partner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartnerRefAppTests {

    @Test
    void contextLoads() {
    }

}
