package org.example.ngp.reference.partner.service.test;

import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.example.ngp.reference.partner.mapper.PartnerMapper;
import org.example.ngp.reference.partner.model.PartnerEntity;
import org.example.ngp.reference.partner.repository.PartnerRepository;
import org.example.ngp.reference.partner.service.DefaultPartnerService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@SpringBootTest
public class DefaultPartnerServiceTest {

    @InjectMocks
    DefaultPartnerService defaultPartnerService;

    @Mock
    private PartnerRepository partnerRepository;

    @Mock
    private PartnerMapper partnerMapper;

    private UUID PARTNER_UUID;

    @BeforeEach
    void setUp() {
        PARTNER_UUID = UUID.fromString("3d5b082e-8d6b-4f1e-b060-c2b5d3ddf734");
    }

    @Test
    public void addPartner() throws InvalidPartnerPropertiesException {
        PartnerReq partnerReq = new PartnerReq();
        partnerReq.setPartnerName("ABC");
        partnerReq.setPartnerType("MERCHANT");
        partnerReq.setAcquirerBankId("9256");
        partnerReq.setCardAcceptorId("9319");
        partnerReq.setExternalId("9782");
        partnerReq.setCardAcceptorLocation("Singapore");

        PartnerEntity partnerEntity = new PartnerEntity();
        partnerEntity.setId(UUID.fromString("3d5b082e-8d6b-4f1e-b060-c2b5d3ddf734"));
        partnerEntity.setPartnerName("ABC");
        partnerEntity.setPartnerType("MERCHANT");
        partnerEntity.setAcquirerBankId("9256");
        partnerEntity.setCardAcceptorId("9319");
        partnerEntity.setExternalId("9782");
        partnerEntity.setCardAcceptorLocation("Singapore");


        Mockito.when(partnerRepository.countByAcquirerBankIdAndCardAcceptorId(partnerReq.getAcquirerBankId(), partnerReq.getCardAcceptorId())).thenReturn(0l);

        Mockito.when(partnerMapper.requestDomainToEntity(partnerReq)).thenReturn(partnerEntity);

        Mockito.when(partnerRepository.save(partnerEntity)).thenReturn(partnerEntity);

        Partner partner = new Partner();
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");

        Mockito.when(partnerMapper.entityToDomain(partnerEntity)).thenReturn(partner);
        Partner partnerResult = defaultPartnerService.addPartner(partnerReq);
        Assertions.assertNotNull(partnerResult);

    }

    @Test
    public void addPartner_InvalidPartnerPropertiesException() throws InvalidPartnerPropertiesException {
        PartnerReq partnerReq = new PartnerReq();
        partnerReq.setPartnerName("ABC");
        partnerReq.setPartnerType("MERCHANT");
        partnerReq.setAcquirerBankId("9256");
        partnerReq.setCardAcceptorId("9319");
        partnerReq.setExternalId("9782");
        partnerReq.setCardAcceptorLocation("Singapore");

        PartnerEntity partnerEntity = new PartnerEntity();
        partnerEntity.setId(UUID.fromString("3d5b082e-8d6b-4f1e-b060-c2b5d3ddf734"));
        partnerEntity.setPartnerName("ABC");
        partnerEntity.setPartnerType("MERCHANT");
        partnerEntity.setAcquirerBankId("9256");
        partnerEntity.setCardAcceptorId("9319");
        partnerEntity.setExternalId("9782");
        partnerEntity.setCardAcceptorLocation("Singapore");


        Mockito.when(partnerRepository.countByAcquirerBankIdAndCardAcceptorId(partnerReq.getAcquirerBankId(), partnerReq.getCardAcceptorId())).thenReturn(1l);

        Mockito.when(partnerMapper.requestDomainToEntity(partnerReq)).thenReturn(partnerEntity);

        Mockito.when(partnerRepository.save(partnerEntity)).thenReturn(partnerEntity);

        Partner partner = new Partner();
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");

        Mockito.when(partnerMapper.entityToDomain(partnerEntity)).thenReturn(partner);
        Assertions.assertThrows(InvalidPartnerPropertiesException.class, () -> defaultPartnerService.addPartner(partnerReq));

    }

    @Test
    public void getPartnersById() throws RecordNotFoundException {
        PartnerEntity partnerEntity = new PartnerEntity();
        partnerEntity.setId(PARTNER_UUID);
        partnerEntity.setPartnerName("ABC");
        partnerEntity.setPartnerType("MERCHANT");
        partnerEntity.setAcquirerBankId("9256");
        partnerEntity.setCardAcceptorId("9319");
        partnerEntity.setExternalId("9782");
        partnerEntity.setCardAcceptorLocation("Singapore");

        Optional<PartnerEntity> partnerEntityOptionalObj = Optional.of(partnerEntity);
        Mockito.when(partnerRepository.findById(PARTNER_UUID)).thenReturn(partnerEntityOptionalObj);

        Partner partner = new Partner();
        partner.setPartnerId(PARTNER_UUID);
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");

        Mockito.when(partnerMapper.entityToDomain(partnerEntity)).thenReturn(partner);
        Partner partnerResult = defaultPartnerService.getPartnersById(PARTNER_UUID);
        Assertions.assertNotNull(partnerResult);
        Assertions.assertEquals(partnerResult.getPartnerId(), PARTNER_UUID);
    }

    @Test
    public void getPartnersById_RecordNotFoundException() throws RecordNotFoundException {
        PartnerEntity partnerEntity = new PartnerEntity();
        partnerEntity.setId(PARTNER_UUID);
        partnerEntity.setPartnerName("ABC");
        partnerEntity.setPartnerType("MERCHANT");
        partnerEntity.setAcquirerBankId("9256");
        partnerEntity.setCardAcceptorId("9319");
        partnerEntity.setExternalId("9782");
        partnerEntity.setCardAcceptorLocation("Singapore");

        Optional<PartnerEntity> partnerEntityOptionalObj = Optional.empty();
        Mockito.when(partnerRepository.findById(PARTNER_UUID)).thenReturn(partnerEntityOptionalObj);
        Assertions.assertThrows(RecordNotFoundException.class, () -> defaultPartnerService.getPartnersById(PARTNER_UUID));
    }

    @Test
    public void getAllPartners() {
        PartnerEntity partnerEntity = new PartnerEntity();
        partnerEntity.setId(PARTNER_UUID);
        partnerEntity.setPartnerName("ABC");
        partnerEntity.setPartnerType("MERCHANT");
        partnerEntity.setAcquirerBankId("9256");
        partnerEntity.setCardAcceptorId("9319");
        partnerEntity.setExternalId("9782");
        partnerEntity.setCardAcceptorLocation("Singapore");

        List<PartnerEntity> partnerEntityList = new ArrayList<>();
        partnerEntityList.add(partnerEntity);

        Pageable pageable = PageRequest.of(0, 10);
        Page<PartnerEntity> pageResult = new PageImpl<PartnerEntity>(partnerEntityList, pageable, 1);

        Mockito.when(partnerRepository.findAll(pageable)).thenReturn(pageResult);
        Page<Partner> allPartners = defaultPartnerService.getAllPartners(0, 10);
        Assertions.assertNotNull(allPartners);
        Assertions.assertNotNull(allPartners.getContent());
    }
}
