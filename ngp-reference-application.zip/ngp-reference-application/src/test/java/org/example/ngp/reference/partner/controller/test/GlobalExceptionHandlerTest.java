package org.example.ngp.reference.partner.controller.test;

import java.sql.SQLException;
import org.example.ngp.reference.partner.controller.advice.GlobalExceptionHandler;
import org.example.ngp.reference.partner.domain.Response;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class GlobalExceptionHandlerTest {

  private final GlobalExceptionHandler globalExceptionHandler = new GlobalExceptionHandler();

  @Test
  public void recordNotFoundExceptionHandler() {
    ResponseEntity<Response<Object>> response =
        globalExceptionHandler.recordNotFoundExceptionHandler(
            new RecordNotFoundException("recordNotFoundException", new Exception()));
    Assertions.assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
  }

  @Test
  public void invalidPartnerPropertiesExceptionHandler() {
    ResponseEntity<Response<Object>> response =
        globalExceptionHandler.invalidPartnerPropertiesExceptionHandler(
            new InvalidPartnerPropertiesException(
                "invalidPartnerPropertiesException", new Exception()));

    Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
  }

  @Test
  public void sqlExceptionHandler() {
    ResponseEntity<Response<Object>> response =
        globalExceptionHandler.sqlExceptionHandler(new SQLException("SQLException"));
    Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
  }

  @Test
  public void defaultExceptionHandler() {
    ResponseEntity<Response<Object>> response =
        globalExceptionHandler.defaultExceptionHandler(new Exception());
    Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
  }
}
