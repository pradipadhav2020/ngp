package org.example.ngp.reference.partner.controller.test;

import org.example.ngp.reference.partner.controller.PartnerController;
import org.example.ngp.reference.partner.domain.PageData;
import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.Response;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.example.ngp.reference.partner.service.PartnerService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@SpringBootTest
public class PartnerControllerTest {

    @InjectMocks
    private PartnerController partnerController;

    @Mock
    private PartnerService partnerService;

    private UUID PARTNER_UUID;

    @BeforeEach
    public void setUP() {
        PARTNER_UUID = UUID.fromString("3d5b082e-8d6b-4f1e-b060-c2b5d3ddf734");
    }

    @Test
    public void addPartner() throws InvalidPartnerPropertiesException {
        PartnerReq partnerReq = new PartnerReq();
        partnerReq.setPartnerName("ABC");
        partnerReq.setPartnerType("MERCHANT");

        Partner partner = new Partner();
        partner.setPartnerId(PARTNER_UUID);
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");

        Mockito.when(partnerService.addPartner(partnerReq)).thenReturn(partner);
        ResponseEntity<Response<Partner>> responseEntity = partnerController.addPartner(partnerReq);
        Assertions.assertNotNull(responseEntity);
        Response<Partner> response = responseEntity.getBody();
        Assertions.assertNotNull(response.getData());
        Assertions.assertEquals("CREATED", responseEntity.getStatusCode().name());
        Assertions.assertEquals(201, responseEntity.getStatusCodeValue());
    }

    @Test
    public void getAllPartner() {
        Partner partner = new Partner();
        partner.setPartnerId(PARTNER_UUID);
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");

        List<Partner> partners = new ArrayList<>();
        partners.add(partner);
        Pageable pageable = PageRequest.of(0, 10);
        Page<Partner> allPartners = new PageImpl<Partner>(partners, pageable, 1);
        Mockito.when(partnerService.getAllPartners(0, 10)).thenReturn(allPartners);
        ResponseEntity<Response<PageData<Partner>>> responseEntity =
                partnerController.getAllPartner(0, 10);
        Response<PageData<Partner>> response = responseEntity.getBody();
        Assertions.assertNotNull(responseEntity);
        Assertions.assertEquals(200, responseEntity.getStatusCode().value());
    }

    @Test
    public void getPartnerById() throws RecordNotFoundException {
        Partner partner = new Partner();
        partner.setPartnerId(PARTNER_UUID);
        partner.setPartnerName("ABC");
        partner.setPartnerType("MERCHANT");
        partner.setAcquirerBankId("9256");
        partner.setCardAcceptorId("9319");
        partner.setExternalId("9782");
        partner.setCardAcceptorLocation("Singapore");
        Mockito.when(partnerService.getPartnersById(PARTNER_UUID)).thenReturn(partner);

        ResponseEntity<Response<Partner>> responseEntity = partnerController.getPartnerById(PARTNER_UUID);
        Assertions.assertNotNull(responseEntity);
        Assertions.assertEquals(200, responseEntity.getStatusCode().value());
    }
}
