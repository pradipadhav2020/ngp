//api config
const app = {
    api: {
        partner: "http://localhost:8080/api/partners"
    }
}

// Navigation Config
const routConfig = [
    {
        defult: true,
        name: "Partner",
        path: "partner",
        page: "partner/partner.html",
        js: ["partner/partner.js"]
    },
    {
        name: "Terminal",
        path: "terminal",
        page: "terminal/terminal.html",
        js: []
    },
    {
        name: "Enrolment",
        path: "enrolment",
        page: "enrolment/enrolment.html",
        js: []
    }

];

//auto close popup config
const autoClosePopupTimeOut = 2000;