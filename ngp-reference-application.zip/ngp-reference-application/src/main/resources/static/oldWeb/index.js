
function addingJsOfViews() {
  let head = document.getElementsByTagName("head")[0];
  routConfig.forEach(r => {
    let js = r["js"];
    if (js != null && js != undefined && js.length > 0) {
      js.forEach(j => {
        let script = document.createElement("script");
        script.setAttribute("src", j);
        head.appendChild(script);
      })
    }
  });
}

addingJsOfViews();

function showInfoAlert(message){
  $('#infoPopUp').modal('toggle');
  document.getElementById("infoPopupMessage").innerHTML = message;
}

function showDangerAlert(message){
  $('#dangerPopUp').modal('toggle');
  document.getElementById("dangerPopupMessage").innerHTML = message;
}

//bootstraping stuff 
$(document).ready(function(){
  // Activate tooltip
  $('[data-toggle="tooltip"]').tooltip();

  //setting timeout popup
  $(function () {
    $('#infoPopUp').on('show.bs.modal', function () {
      let myModal = $(this);
      clearTimeout(myModal.data('infoPopUpHideInterval'));
      myModal.data('infoPopUpHideInterval', setTimeout(function () {
        myModal.modal('hide');
      }, autoClosePopupTimeOut));
    });
  });
  $(function () {
    $('#dangerPopUp').on('show.bs.modal', function () {
      let myModal = $(this);
      clearTimeout(myModal.data('dangerPopUpHideInterval'));
      myModal.data('dangerPopUpHideInterval', setTimeout(function () {
        myModal.modal('hide');
      }, autoClosePopupTimeOut));
    });
  });

  // Create nav bar
  var navBar = document.getElementById("navNar");
  var url = window.location.href + "";
  routConfig.forEach(i => {
    let a = document.createElement("a");
    // a.classList.add("table-title");
    a.innerHTML = i.name;
    navBar.appendChild(a);
    a.onclick = function (e) {
      history.pushState({ rout: i }, i.name, "#" + i.path);
      return false;
    };
  });
  populateCurrentView();
});

(function (history) {
  var pushState = history.pushState;
  history.pushState = function (state) {
    if (typeof history.onpushstate == "function") {
      history.onpushstate({
        state: state
      });
    }
    return pushState.apply(history, arguments);
  }
})(window.history);

window.onpopstate = history.onpushstate = function (e) {
  if (e.state != null) {
    includeHTML(e.state.rout.page, document.getElementById("root"));
  }
};

//populate current view
function populateCurrentView() {
  let href = window.location.href;
  if (href.includes("#")) {
    let rout = routConfig.find(i => href.split("#")[1] == i.path);
    if (rout == null && !rout) {
      rout = routConfig.find(i => i["defult"] != null && i["defult"]);
    }
    includeHTML(rout.page, document.getElementById("root"));
  } else {
    includeHTML(routConfig.find(i => i["defult"] != null && i["defult"]).page, document.getElementById("root"));
  }
};

function includeHTML(file, elmnt) {
  var elmnt, file;
  if (elmnt != null && elmnt.lastElementChild != null && elmnt.lastElementChild) {
    while (elmnt.lastElementChild) {
      elmnt.removeChild(elmnt.lastElementChild);
    }
  }
  if (file) {
    /*make an HTTP request using the attribute value as the file name:*/
    fetch(file)
      .then((response) => response.text())
      .then((data) => {
        let div = document.createElement("div");
        div.innerHTML = data;
        nodeScriptReplace(div);
        elmnt.appendChild(div);
      })
      .catch(e => console.error(e));
    return;
  }
};

//replacing script tags
function nodeScriptReplace(node) {
  if (nodeScriptIs(node) === true) {
    node.parentNode.replaceChild(nodeScriptClone(node), node);
  }
  else {
    var i = -1, children = node.childNodes;
    while (++i < children.length) {
      nodeScriptReplace(children[i]);
    }
  }

  return node;
}
function nodeScriptClone(node) {
  var script = document.createElement("script");
  script.text = node.innerHTML;

  var i = -1, attrs = node.attributes, attr;
  while (++i < attrs.length) {
    script.setAttribute((attr = attrs[i]).name, attr.value);
  }
  return script;
}
function nodeScriptIs(node) {
  return node.tagName === 'SCRIPT';
}