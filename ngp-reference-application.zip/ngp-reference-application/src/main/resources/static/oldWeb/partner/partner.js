const paginationDetail = {
    pageNumber: 1,
    pageSize: 10,
    totalPages: 0,
    totalRecords: 0
};


function initPartner() {
    populateTable();
    intAddPartnerFormHandelr();
    intEditPartnerFormHandelr();
}


//===================================Table creation and population ======================================
function populateTable() {
    let tableBody = document.getElementById("partnerTableBody");
    if (tableBody != null) {
        fetchPartners(paginationDetail.pageNumber-1, paginationDetail.pageSize, res => {
            let data = res["data"];
            let rows = data != null && data["content"] != null ? data["content"] : [];
            tableBody.innerHTML = createRows(rows);
            populatePagination(data);
        });
    } else {
        console.error("Table body not found..!");
    }
};

function createRows(rowsObj) {
    let rows = "";
    if (rowsObj != null && rowsObj.length > 0) {
        rowsObj.forEach(row => {
            rows = rows + createRow(row);
        });
    }
    return rows;
}

function createRow(rowObj) {
    return '<tr>'
        + ' <td>' + rowObj.partnerName + '</td>'
        + ' <td>' + rowObj.partnerType + '</td>'
        + ' <td>' + rowObj.acquirerBankId + '</td>'
        + ' <td>' + rowObj.cardAcceptorId + '</td>'
        + ' <td>' + rowObj.cardAcceptorLocation + '</td>'
        + ' <td>'
        + '    <a attr-partner-id = "' + rowObj.partnerId + '" style=" color: #fff; padding: 1px 2px;" onclick="editPartnerButtonHandelr(\'' + rowObj.partnerId + '\')" class="btn btn-success" data-toggle="modal"><span>Edit</span></a>'
        + '    <a attr-partner-id = "' + rowObj.partnerId + '" style=" color: #fff; padding: 1px 2px;" onclick="deletePartnerButtonHandelr(\'' + rowObj.partnerId + '\')" class="btn btn-danger" data-toggle="modal"><span>Delete</span></a>'
        + ' </td>'
        + '</tr>';
}

async function fetchPartners(pageNumber, pageSize, callback) {
    let requestOptions = {
        method: 'GET'
    };

    fetch(app.api.partner + "?pageNo=" + pageNumber + "&pageSize=" + pageSize, requestOptions)
        .then(response => response.json())
        .then(response => {
            if (response["statusCode"] == 200) {
                callback(response);
            } else {
                showDangerAlert(response["message"] != undefined ? response["message"] : response["error"] != undefined ? response["error"] : "Something went wrong, Please try again later...!");
            }
        })
        .catch(error => {
            showDangerAlert("Something went wrong, Please try again later...!");
            console.log('error', error);
        });
};

//===================================Table pagination creation and population ======================================
function populatePagination(data) {
    let totalPages = (data != null && data["totalPages"] != null ? data["totalPages"] : 0);
    paginationDetail.totalPages = totalPages;
    paginationDetail.totalRecords = (data != null && data["totalRecord"] != null ? data["totalRecord"] : 0);

    enabledDisabledPaginationButtons();

    populatePaginationDetail();
}

function enabledDisabledPaginationButtons() {
    let nextPageBtn = document.getElementById("nextPageBtn");
    let previousPageBtn = document.getElementById("previousPageBtn");
    if (paginationDetail.pageNumber < paginationDetail.totalPages) {
        nextPageBtn.classList.remove("disabled");
    } else {
        nextPageBtn.classList.add("disabled");
    }
    if (paginationDetail.pageNumber > 1) {
        previousPageBtn.classList.remove("disabled");
    } else {
        previousPageBtn.classList.add("disabled");
    }
}

function populatePaginationDetail() {
    let pageNo = paginationDetail.pageNumber;
    let startPageFrom = paginationDetail.totalPages > 0 ? (((pageNo - 1) * paginationDetail.pageSize) + 1) : paginationDetail.totalPages;
    let endPageTo = paginationDetail.totalPages > 0 ? ((startPageFrom + paginationDetail.pageSize) - 1) : paginationDetail.totalPages;
    endPageTo = endPageTo > paginationDetail.totalRecords ? paginationDetail.totalRecords : endPageTo;
    document.getElementById("showingRecords").innerHTML = startPageFrom > 0 && paginationDetail.totalPages > 0 ? (startPageFrom == endPageTo? startPageFrom : (startPageFrom + ' - ' +endPageTo )) : 0;
    document.getElementById("totalRecords").innerHTML = paginationDetail.totalRecords;
}

function handleNextPageButtonClick() {
    if (paginationDetail.totalPages > paginationDetail.pageNumber) {
        paginationDetail.pageNumber = paginationDetail.pageNumber + 1;
        populateTable(paginationDetail.pageNumber, paginationDetail.pageSize);
    }
};

function handlePreviousPageButtonClick() {
    if (paginationDetail.pageNumber > 1) {
        paginationDetail.pageNumber = paginationDetail.pageNumber - 1;
        populateTable(paginationDetail.pageNumber, paginationDetail.pageSize);
    }
};


//==========================================Add Partner===================================
function intAddPartnerFormHandelr() {
    let addPartnerForm = document.getElementById('addPartnerForm');
    addPartnerForm.addEventListener('submit', (e) => {
        e.preventDefault()
        addPartner(addPartnerForm);
    });
}

function addPartner(addPartnerForm) {
    let formData = new FormData(addPartnerForm);

    let headers = new Headers();
    headers.append("Content-Type", "application/json");

    let raw = JSON.stringify({
        "partnerName": formData.get('name'),
        "partnerType": formData.get('type'),
        "acquirerBankId": formData.get('acquirerBankId'),
        "cardAcceptorId": formData.get('cardAcceptorId'),
        "externalId": formData.get('externalId'),
        "cardAcceptorLocation": formData.get('location')
    });

    var requestOptions = {
        method: 'POST',
        headers: headers,
        body: raw
    };

    fetch(app.api.partner, requestOptions)
        .then(response => response.json())
        .then(response => {
            if (response["statusCode"] == 201) {
                showInfoAlert("Partner added successfully");
                populateTable();
            } else {
                showDangerAlert(response["message"] != undefined ? response["message"] : response["error"] != undefined ? response["error"] : "Somthing went wrong, Please try again later...!");
            }
        })
        .catch(error => {
            showDangerAlert("Somthing went wrong, Please try again later...!");
            console.log('error', error);
        });



    //closing dailog
    $('#addPartnerModal').modal('toggle');
    addPartnerForm.reset();
}

//==========================================Edit Partner===================================
function intEditPartnerFormHandelr() {
    let editPartnerForm = document.getElementById('editPartnerForm');
    editPartnerForm.addEventListener('submit', (e) => {
        e.preventDefault()
        saveEditedParant(editPartnerForm);
    });
}

function openEditPartnerDailog(partnerObj) {
    //opennig dailog
    $('#editPartnerModal').modal('toggle');

    document.getElementById("editPartnerId").value = partnerObj.partnerId;
    document.getElementById("editNameField").value = partnerObj.partnerName;
    document.getElementById("editTypeField").value = partnerObj.partnerType;
    document.getElementById("editAcquirerBankIdField").value = partnerObj.acquirerBankId;
    document.getElementById("editCardAcceptorIdField").value = partnerObj.cardAcceptorId;
    document.getElementById("editExternalIdField").value = partnerObj.externalId;
    document.getElementById("editLocationField").value = partnerObj.cardAcceptorLocation;
}

function editPartnerButtonHandelr(partnerId) {
    let requestOptions = {
        method: 'GET'
    };

    fetch(app.api.partner + "/" + partnerId, requestOptions)
        .then(response => response.json())
        .then(response => {
            if (response["statusCode"] == 200) {
                if (response.data != null ) {
                    openEditPartnerDailog(response.data);
                } else {
                    showDangerAlert("Partner not found..!");
                }
            } else {
                showDangerAlert(response["message"] != undefined ? response["message"] : response["error"] != undefined ? response["error"] : "Somthing went wrong, Please try again later...!");
            }
        })
        .catch(error => {
            showDangerAlert("Somthing went wrong, Please try again later...!");
            console.log('error', error);
        });
}

function saveEditedParant(editPartnerForm) {
    let formData = new FormData(editPartnerForm);
    let partnerId = formData.get('partnerId');
    let partner = {
        "partnerId": partnerId,
        "partnerName": formData.get('name'),
        "partnerType": formData.get('type'),
        "acquirerBankId": formData.get('acquirerBankId'),
        "cardAcceptorId": formData.get('cardAcceptorId'),
        "externalId": formData.get('externalId'),
        "cardAcceptorLocation": formData.get('location')
    }
    //api call here

    //closing dailog
    $('#editPartnerModal').modal('toggle');
    // editPartnerForm.reset();
    populateTable();
}

//==========================================Delete Partner===================================
function deletePartnerButtonHandelr(partnerId) {
    //stting partner id in details dailog
    document.getElementById("deletePartnerId").value = partnerId;
    $('#deleteEmployeeModal').modal('toggle');
}

function deletePartnerConfirmHandler() {
    //api call here

    //closing dailog
    $('#deleteEmployeeModal').modal('toggle');
    // editPartnerForm.reset();
    populateTable();
}