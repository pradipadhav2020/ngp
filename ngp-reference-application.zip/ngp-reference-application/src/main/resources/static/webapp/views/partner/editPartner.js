var params = new URL(document.location).searchParams;
var partnerId = params.get("partnerId");

(() => getPartnerById())();

function searchPartnerById(){
    window.location.href="editPartner.html?partnerId="+document.getElementById("searchId").value.trim();
}

function enrichFields(partnerObj) {
    document.getElementById("partnerName").value = partnerObj.partnerName;
    document.getElementById("partnerType").value = partnerObj.partnerType;
    document.getElementById("acquirerBankId").value = partnerObj.acquirerBankId;
    document.getElementById("cardAcceptorId").value = partnerObj.cardAcceptorId;
    document.getElementById("externalId").value = partnerObj.externalId;
    document.getElementById("partnerlocation").value = partnerObj.cardAcceptorLocation;
    window.location.href="#partner-form"
}

function getPartnerById() {
    var params = new URL(document.location).searchParams;
    var partnerId = params.get("partnerId");
    if (partnerId != null || partnerId != undefined) {
        partnerId = partnerId.trim()
        document.getElementById("searchId").value = partnerId;
        let requestOptions = {
            method: 'GET'
        };
        let url = SERVER_URL + "/api/partners/" + partnerId;
        document.getElementById("url").value = url;
        document.getElementById("apiMethod").value = requestOptions.method;
        $("#spinner").addClass("loading");
        fetch(url, requestOptions)
            .then(response => response.json())
            .then(response => {
                document.getElementById("response-object").value = JSON.stringify(response, null, 4);
                if (response["statusCode"] == 200) {
                    if (response.data != null) {
                        enrichFields(response.data);
                    }
                }
                $("#spinner").removeClass("loading");
            })
            .catch(error => {
                console.log('error', error);
                $("#spinner").removeClass("loading");
            });
    }
}

function saveEditedParant(editPartnerForm) {
    let formData = new FormData(editPartnerForm);
    let partnerId = formData.get('partnerId');
    let partner = {
        "partnerId": partnerId,
        "partnerName": formData.get('name'),
        "partnerType": formData.get('type'),
        "acquirerBankId": formData.get('acquirerBankId'),
        "cardAcceptorId": formData.get('cardAcceptorId'),
        "externalId": formData.get('externalId'),
        "cardAcceptorLocation": formData.get('location')
    }
    //api call here

}
