$(function () {
    $('[data-toggle="tooltip"]').tooltip();

    // set form jQuery validator
    $("#partner-form").validate({
        ignore: [],
        normalizer: function (value) {
            return $.trim(value);
        },
        rules: {
            partnerName: {
                required: true
                // pattern: "^[0-9a-zA-Z#_-]*$",
            },
            // partnerType: {
            //     required: true
            // },
            srcCorrelationId: {
                required: true
            },
            acquirerBankId: {
                required: true
            },
            cardAcceptorId: {
                required: true
            },
            externalId: {
                required: true
            },
            partnerlocation: {
                required: true
            }
        },
        messages: {},
        submitHandler: function (_form, event) {
            event.preventDefault();
        },
    });

    // on create button click submit form
    $(document).on("click", "#submitBtn", function () {
        if ($("#partner-form").valid()) {
            $("#spinner").addClass("loading");
            var request_object = createRequestObject();
            let url = SERVER_URL + "/api/partners";
            document.getElementById("url").value = url;
            // API CALL Secure Card on File POST Enrol Card
            $.ajax({
                data: JSON.stringify(request_object),
                url: url,
                type: "POST",
                dataType: "json",
                headers: {
                    "Content-Type": "application/json",
                },
                success: function (response, _statusCode, _xhr) {
                    $("#partner-form").trigger("reset");
                    $("#spinner").removeClass("loading");
                    $("#submitBtn").attr(
                        "data-partner-request",
                        JSON.stringify($("#partner-form").serializeArray())
                    );
                    $("#submitBtn").attr(
                        "data-partner-response",
                        JSON.stringify(response)
                    );
                    // Below code is use to format response json object
                    $("#response-object").text(
                        JSON.stringify(response, undefined, 4)
                    );
                },
                error: function (jqXHR, _textStatus, _errorThrown) {
                    $("#spinner").removeClass("loading");
                    // Below code is use to format errorThrown json object
                    $("#response-object").text(
                        JSON.stringify(
                            JSON.parse(jqXHR.responseText),
                            undefined,
                            4
                        )
                    );
                },
            });
        }
    });

    function createRequestObject() {
        // Below code is use to format request json object
        var serialized = $("#partner-form").serializeArray();
        var data = {};
        for (var s in serialized) {
            data[serialized[s]["name"]] = serialized[s]["value"];
        }
        /*********************  code block to add partner object *******************/
        console.log(data)
        var partner = {
            partnerName: data.partnerName,
            partnerType: data.partnerType,
            acquirerBankId: data.acquirerBankId,
            cardAcceptorId: data.cardAcceptorId,
            externalId: data.externalId,
            cardAcceptorLocation: data.partnerlocation
        };
        var req = JSON.stringify(partner, null, 4);
        $("#request-object").text(req);
        return partner;
    }

});
