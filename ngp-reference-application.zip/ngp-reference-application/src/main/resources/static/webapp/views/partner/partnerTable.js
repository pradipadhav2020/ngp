var paginationDetail = {
    pageNumber: 1,
    pageSize: 10,
    totalPages: 0,
    totalRecords: 0
};

(() => populateTable())();

function populateTable() {
    let tableBody = document.getElementById("partnerTableBody");
    if (tableBody != null) {
        fetchPartners(paginationDetail.pageNumber - 1, paginationDetail.pageSize, res => {
            let data = res["data"];
            let rows = data != null && data["content"] != null ? data["content"] : [];
            tableBody.innerHTML = createRows(rows);
            populatePagination(data);
        });
    } else {
        console.error("Table body not found..!");
    }
};

function createRows(rowsObj) {
    let rows = "";
    if (rowsObj != null && rowsObj.length > 0) {
        rowsObj.forEach(row => {
            rows = rows + createRow(row);
        });
    }
    return rows;
}

function createRow(rowObj) {
    return '<tr>'
        + ' <td>' + rowObj.partnerId + '</td>'
        + ' <td>' + rowObj.partnerName + '</td>'
        + ' <td>' + rowObj.partnerType + '</td>'
        + ' <td>' + rowObj.acquirerBankId + '</td>'
        + ' <td>' + rowObj.cardAcceptorId + '</td>'
        + ' <td>' + rowObj.cardAcceptorLocation + '</td>'
        + ' <td>'
        + '    <a attr-partner-id = "' + rowObj.partnerId + '" style=" color: #fff; padding: 1px 2px;" onclick="location.href=\'editPartner.html?partnerId='+rowObj.partnerId+'\';" class="btn btn-success" data-toggle="modal"><span>View</span></a>'
        + ' </td>'
        + '</tr>';
}

function fetchPartners(pageNumber, pageSize, callback) {
    $("#spinner").addClass("loading");
    let requestOptions = {
        method: 'GET'
    };
    let url = SERVER_URL + "/api/partners?pageNo=" + pageNumber + "&pageSize=" + pageSize;
    document.getElementById("url").value = url;
    fetch(url, requestOptions)
        .then(response => response.json())
        .then(response => {
            document.getElementById("response-object").value = JSON.stringify(response, null, 4);
            if (response["statusCode"] == 200) {
                callback(response);
            }
            $("#spinner").removeClass("loading");
        })
        .catch(error => {
            console.log('error', error);
            $("#spinner").removeClass("loading");
        });
};

//===================================Table pagination creation and population ======================================
function populatePagination(data) {
    let totalPages = (data != null && data["totalPages"] != null ? data["totalPages"] : 0);
    paginationDetail.totalPages = totalPages;
    paginationDetail.totalRecords = (data != null && data["totalRecord"] != null ? data["totalRecord"] : 0);

    enabledDisabledPaginationButtons();

    populatePaginationDetail();
}

function enabledDisabledPaginationButtons() {
    let nextPageBtn = document.getElementById("nextPageBtn");
    let previousPageBtn = document.getElementById("previousPageBtn");
    if (paginationDetail.pageNumber < paginationDetail.totalPages) {
        nextPageBtn.classList.remove("disabled");
    } else {
        nextPageBtn.classList.add("disabled");
    }
    if (paginationDetail.pageNumber > 1) {
        previousPageBtn.classList.remove("disabled");
    } else {
        previousPageBtn.classList.add("disabled");
    }
}

function populatePaginationDetail() {
    let pageNo = paginationDetail.pageNumber;
    let startPageFrom = paginationDetail.totalPages > 0 ? (((pageNo - 1) * paginationDetail.pageSize) + 1) : paginationDetail.totalPages;
    let endPageTo = paginationDetail.totalPages > 0 ? ((startPageFrom + paginationDetail.pageSize) - 1) : paginationDetail.totalPages;
    endPageTo = endPageTo > paginationDetail.totalRecords ? paginationDetail.totalRecords : endPageTo;
    document.getElementById("showingRecords").innerHTML = startPageFrom > 0 && paginationDetail.totalPages > 0 ? (startPageFrom == endPageTo ? startPageFrom : (startPageFrom + ' - ' + endPageTo)) : 0;
    document.getElementById("totalRecords").innerHTML = paginationDetail.totalRecords;
}

function handleNextPageButtonClick() {
    if (paginationDetail.totalPages > paginationDetail.pageNumber) {
        paginationDetail.pageNumber = paginationDetail.pageNumber + 1;
        populateTable(paginationDetail.pageNumber, paginationDetail.pageSize);
        window.location.href="#partnerTable"
    }
};

function handlePreviousPageButtonClick() {
    if (paginationDetail.pageNumber > 1) {
        paginationDetail.pageNumber = paginationDetail.pageNumber - 1;
        populateTable(paginationDetail.pageNumber, paginationDetail.pageSize);
    }
};

