
INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Yogesh','MERCHANT','1234','2345','6789','India');

INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Pradip','MERCHANT','2234','3345','7789','India');

INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Tejas','MERCHANT','3234','4345','8789','Singapore');

INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Arie','MERCHANT','4234','5345','9789','Singapore');

INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Aung','MERCHANT','5234','6345','9781','Singapore');

INSERT INTO Partner (partner_name,partner_type,acquirer_bank_id,card_acceptor_id,external_id,card_acceptor_location)
VALUES ('Srinath','MERCHANT','6234','7345','9782','India');
