DROP TABLE IF EXISTS Partner;
CREATE TABLE Partner (
	id uuid default random_uuid(),
	partner_name varchar(255),
	partner_type varchar(255),
	acquirer_bank_id varchar(255),
	card_acceptor_id varchar(255),
	external_id varchar(255),
	card_acceptor_location varchar(255),
	CONSTRAINT UC_Partner UNIQUE (acquirer_bank_id,card_acceptor_id)
);