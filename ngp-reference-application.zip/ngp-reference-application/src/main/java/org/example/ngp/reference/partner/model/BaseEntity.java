package org.example.ngp.reference.partner.model;

import java.io.Serializable;

/*@MappedSuperclass
@EntityListeners({AuditingEntityListener.class})*/
public abstract class BaseEntity implements Serializable {

/*    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;*/
}