package org.example.ngp.reference.partner.exception;

public class InvalidPartnerPropertiesException extends Exception {
    public InvalidPartnerPropertiesException(String message) {
        super(message);
    }

    public InvalidPartnerPropertiesException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
