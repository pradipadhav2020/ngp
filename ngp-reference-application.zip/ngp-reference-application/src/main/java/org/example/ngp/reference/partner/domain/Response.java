package org.example.ngp.reference.partner.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Response<T> {
    private String status;
    private int statusCode;
    private String message;
    private T data;

    public static <T> Response<T> of(T data, String status, int statusCode, String message) {
        return new Response<T>(status, statusCode, message, data);
    }

    public static <T> ResponseEntity<Response<T>> of(T data, HttpStatus status, String message) {
        var response = of(data, status.name(), status.value(), message);
        return new ResponseEntity<Response<T>>(response, status);
    }

    public static <T> ResponseEntity<Response<T>> of(HttpStatus status, String message) {
        return of(null, status, message);
    }

    public static <T> ResponseEntity<Response<T>> ofSuccess(T data, String message) {
        return of(data, HttpStatus.OK, message);
    }

    public static <T> ResponseEntity<Response<T>> ofSuccess(String message) {
        return of(HttpStatus.OK, message);
    }

    public static  <T> ResponseEntity<Response<PageData<T>>> ofPage(Page<T> page, HttpStatus status, String message) {
        return of(new PageData<T>(page), status, message);
    }

    public static  <T> ResponseEntity<Response<PageData<T>>> ofPage(Page<T> page, String message) {
        return ofPage(page, HttpStatus.OK, message);
    }
}
