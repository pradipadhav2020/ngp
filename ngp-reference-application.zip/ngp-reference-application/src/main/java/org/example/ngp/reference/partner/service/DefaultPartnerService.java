package org.example.ngp.reference.partner.service;

import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.example.ngp.reference.partner.mapper.PartnerMapper;
import org.example.ngp.reference.partner.model.PartnerEntity;
import org.example.ngp.reference.partner.repository.PartnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class DefaultPartnerService implements PartnerService {

    @Autowired
    private PartnerRepository partnerRepository;

    @Autowired
    private PartnerMapper partnerMapper;


    @Override
    public Partner addPartner(PartnerReq partnerReq) throws InvalidPartnerPropertiesException {
        if (partnerRepository.countByAcquirerBankIdAndCardAcceptorId(partnerReq.getAcquirerBankId(), partnerReq.getCardAcceptorId()) > 0) {
            throw new InvalidPartnerPropertiesException("Partner already exist with Acquirer and Acceptor ID");
        }
        PartnerEntity partnerEntity = partnerMapper.requestDomainToEntity(partnerReq);
        partnerEntity = partnerRepository.save(partnerEntity);
        Partner partner = partnerMapper.entityToDomain(partnerEntity);
        return partner;
    }

    @Override
    public Partner getPartnersById(UUID id) throws RecordNotFoundException {
        Optional<PartnerEntity> partnerEntity = partnerRepository.findById(id);
        if (partnerEntity.isEmpty()) {
            throw new RecordNotFoundException("Partner not found");
        }
        Partner partner = partnerMapper.entityToDomain(partnerEntity.get());
        return partner;
    }

    @Override
    public Page<Partner> getAllPartners(Integer pageNo, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        Page<PartnerEntity> pageResult = partnerRepository.findAll(pageable);
        return pageResult.map(p -> partnerMapper.entityToDomain(p));
    }
}
