package org.example.ngp.reference.partner.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Page;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageData<T> {
    private int pageNumber;
    private int pageSize;
    private int totalPages;
    private long totalRecord;
    private List<T> content;

    public PageData(Page<T> page){
        this.content = page.getContent();
        this.pageNumber = page.getNumber();
        this.totalPages = page.getTotalPages();
        this.totalRecord = page.getTotalElements();
        this.pageSize = page.getSize();
    }
}
