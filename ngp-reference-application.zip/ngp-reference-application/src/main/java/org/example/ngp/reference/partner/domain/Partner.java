package org.example.ngp.reference.partner.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Partner {
    private UUID partnerId;
    private String partnerName;
    private String partnerType;
    private String acquirerBankId;
    private String cardAcceptorId;
    private String externalId;
    private String cardAcceptorLocation;

}
