package org.example.ngp.reference.partner.domain.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartnerReq {
    @NotBlank(message = "Partner name must not be null or blank")
    private String partnerName;
    @NotBlank(message = "Partner type must not be null or blank")
    private String partnerType;
    @NotBlank(message = "Acquirer bank ID must not be null or blank")
    private String acquirerBankId;
    @NotBlank(message = "Card acceptor ID must not be null or blank")
    private String cardAcceptorId;
    @NotBlank(message = "External ID must not be null or blank")
    private String externalId;
    @NotBlank(message = "Card acceptor location must not be null or blank")
    private String cardAcceptorLocation;

}
