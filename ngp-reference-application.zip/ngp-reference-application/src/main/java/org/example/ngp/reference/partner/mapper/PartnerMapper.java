package org.example.ngp.reference.partner.mapper;

import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.model.PartnerEntity;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class PartnerMapper {


    public PartnerEntity requestDomainToEntity(PartnerReq partnerReq) {
        PartnerEntity partner = new PartnerEntity();
        BeanUtils.copyProperties(partnerReq, partner);
        return partner;
    }

    public PartnerEntity domainToEntity(Partner partner) {
        PartnerEntity partnerEntity = new PartnerEntity();
        BeanUtils.copyProperties(partner, partnerEntity);
        partnerEntity.setId(partner.getPartnerId());
        return partnerEntity;
    }

    public Partner entityToDomain(PartnerEntity partnerEntity) {
        Partner partner = new Partner();
        BeanUtils.copyProperties(partnerEntity, partner);
        partner.setPartnerId(partnerEntity.getId());
        return partner;
    }

    public List<Partner> entityToDomain(List<PartnerEntity> partners) {
        Function<PartnerEntity, Partner> fun = (partner) ->  entityToDomain(partner);
        List<Partner> partner = partners.stream().map(fun).collect(Collectors.toList());
        return partner;
    }
}
