package org.example.ngp.reference.partner.service;

import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.springframework.data.domain.Page;

import java.util.UUID;

public interface PartnerService {

    Partner addPartner(PartnerReq partnerReqDomain) throws InvalidPartnerPropertiesException;

    Partner getPartnersById(UUID id) throws RecordNotFoundException;

    Page<Partner> getAllPartners(Integer pageNo, Integer pageSize);
}
