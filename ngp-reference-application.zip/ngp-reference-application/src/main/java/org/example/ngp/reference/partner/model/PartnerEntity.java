package org.example.ngp.reference.partner.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "Partner", uniqueConstraints = {@UniqueConstraint(name = "UC_Partner", columnNames = {"acquirer_bank_id", "card_acceptor_id"})})
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartnerEntity {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;
    @Column(name = "partner_name")
    private String partnerName;
    @Column(name = "partner_type")
    private String partnerType;
    @Column(name = "acquirer_bank_id")
    private String acquirerBankId;
    @Column(name = "card_acceptor_id")
    private String cardAcceptorId;
    @Column(name = "external_id")
    private String externalId;
    @Column(name = "card_acceptor_location")
    private String cardAcceptorLocation;
}
