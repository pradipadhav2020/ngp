package org.example.ngp.reference.partner.controller;

import org.example.ngp.reference.partner.domain.PageData;
import org.example.ngp.reference.partner.domain.Partner;
import org.example.ngp.reference.partner.domain.Response;
import org.example.ngp.reference.partner.domain.request.PartnerReq;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.service.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class PartnerController {

    @Autowired
    PartnerService partnerService;

    @PostMapping(value = "/partners")
    public ResponseEntity<Response<Partner>> addPartner(@Valid @RequestBody PartnerReq partnerReq) throws InvalidPartnerPropertiesException {
        return Response.of(partnerService.addPartner(partnerReq),HttpStatus.CREATED, "Partner has been created successfully");
    }

    @GetMapping(value = "/partners")
    public ResponseEntity<Response<PageData<Partner>>> getAllPartner(@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "10") Integer pageSize) {
        Page<Partner> page = partnerService.getAllPartners(pageNo, pageSize);
        return Response.ofPage(page,"Success");
    }

    @GetMapping("/partners/{id}")
    public ResponseEntity<Response<Partner>> getPartnerById(@PathVariable(name = "id") UUID id) throws RecordNotFoundException {
        return Response.ofSuccess(partnerService.getPartnersById(id), "Success");
    }

}