package org.example.ngp.reference.partner.controller.advice;


import org.example.ngp.reference.partner.domain.Response;
import org.example.ngp.reference.partner.exception.InvalidPartnerPropertiesException;
import org.example.ngp.reference.partner.exception.RecordNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<Response<Object>> methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException ex) {
        List<String> errors = ex.getBindingResult().getFieldErrors()
                .stream().map(FieldError -> FieldError.getDefaultMessage()).collect(Collectors.toList());
        return Response.of(errors, HttpStatus.BAD_REQUEST, errors.get(0));
    }

    @ExceptionHandler(value = RecordNotFoundException.class)
    public ResponseEntity<Response<Object>> recordNotFoundExceptionHandler(RecordNotFoundException ex) {
        return Response.of(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    @ExceptionHandler(value = InvalidPartnerPropertiesException.class)
    public ResponseEntity<Response<Object>> invalidPartnerPropertiesExceptionHandler(InvalidPartnerPropertiesException ex) {
        return Response.of(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    @ExceptionHandler(value = SQLException.class)
    public ResponseEntity<Response<Object>> sqlExceptionHandler(SQLException ex) {
        log.error("SQL Error", ex);
        return Response.of(HttpStatus.BAD_REQUEST, "Something went wrong, Please try again");
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Response<Object>> defaultExceptionHandler(Exception ex) {
        log.error("Error", ex);
        return Response.of(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong, Please try again");
    }
}
