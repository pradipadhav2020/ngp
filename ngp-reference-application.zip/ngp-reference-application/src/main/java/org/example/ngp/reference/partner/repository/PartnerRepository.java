package org.example.ngp.reference.partner.repository;

import org.example.ngp.reference.partner.model.PartnerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PartnerRepository extends JpaRepository<PartnerEntity, UUID> {
    public Long countByAcquirerBankIdAndCardAcceptorId(String acquirerBankId, String cardAcceptorId);
}
